<?php
include('proc/connect.php');
		
if(isset($_SESSION['login_user']))
{
	$u_id=$_SESSION['login_user'];
	$query="select theme_name from themes where theme_id IN (select theme_id from edit where u_id=".$u_id.")";
		$result=mysqli_query($conn,$query);
		while($row=mysqli_fetch_array($result))
		{
				$tnm=$row[0];
		
			$query1="select email from user where u_id=".$u_id."";
			$result1=mysqli_query($conn,$query1);
			while($row=mysqli_fetch_array($result1))
			{
				$unm=$row[0];
				
			}
			$url= 'usertemp/'.$unm.'/'.$tnm.'/home.php';
			
		}
?>

<!DOCTYPE HTML>
<html>
<head>
	<title>WEBBR</title>
		<!-- stylesheet css -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/css/font-awesome.css">
	<link rel="stylesheet" href="css/nivo-lightbox.css">
	<link rel="stylesheet" href="css/nivo_themes/default/default.css">
	<link rel="stylesheet" href="css/style.css">
	<!-- google web font css -->
	<link href='http://fonts.googleapis.com/css?family=Raleway:400,300,600,700' rel='stylesheet' type='text/css'>
</head>
<body data-spy="scroll" data-target=".navbar-collapse">

<!-- navigation -->
<div class="navbar navbar-default" role="navigation">
	<div class="container">
		<div class="navbar-header">
			<button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
				<span class="icon icon-bar"></span>
				<span class="icon icon-bar"></span>
				<span class="icon icon-bar"></span>
			</button>
			<a href="#home" class="navbar-brand smoothScroll">WEBBR</a>
		</div>
		<div class="collapse navbar-collapse">
			<ul	class="nav navbar-nav navbar-right">
			<li><a href="profile.php" class="smoothScroll"><?php $query = "select image,name from user where u_id=$_SESSION[login_user]";
												   $result=mysqli_query($conn,$query);
												   while($row=mysqli_fetch_array($result))
												   {
													?>
												<img class="profile" src="<?php echo $row[0]; ?>" alt="dp"/>	
												<?php echo $row[1];}?>
			</a></li>
			<li><a href="proc/logout_proc.php" class="smoothScroll"><span class="fa fa-sign-out"></span>LOGOUT</a></li>
		</ul>
		</div>
	</div>
</div>
<!-- service section -->
<div id="service">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<h2>Let's Get Started</h2>
			</div>
			
			<div class="col-md-4 col-sm-4 text-center" id="get_started">
				<a href="proc/check_proc.php?edit=1" class="btn btn-default smoothScroll">Edit Your Site</a>
			</div>
			<div class="col-md-4 col-sm-4 text-center" id="get_started">
				<a target=_blank href="<?php echo $url; ?>" class="btn btn-default smoothScroll">See Your Site</a>
			</div>
			<div class="col-md-4 col-sm-4 text-center" id="get_started">
				<a href="proc/check_proc.php?del=1" class="btn btn-default smoothScroll">Delete Your Site</a>
			</div>
		</div>
	</div>
</div>
<!-- divider section -->
<div class="container">
	<div class="row">
		<div class="col-md-1 col-sm-1"></div>
		<div class="col-md-10 col-sm-10">
			<hr>
		</div>
		<div class="col-md-1 col-sm-1"></div>
	</div>
</div>
<?php
if(isset($_REQUEST['error']))
{
 ?>
	<div class="container">
		<div class="row">
			<div class="col-md-4 col-sm-4"></div>
			<div class="col-md-4 col-sm-4">
				<div class="alert alert-danger">
					<p><i class="fa fa-info-circle"></i>For Edit You Need to Select Atleast One theme</p>
				</div>
			</div>
			<div class="col-md-4 col-sm-4"></div>
		</div>
	</div>
<?php } ?>
<!-- template section -->
<?php
 $query="select theme_id from edit where u_id=".$u_id."";
 $result=mysqli_query($conn,$query);
 $num=mysqli_num_rows($result);
 if($num==0)
 {
?>
<div id="about">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<h2>START FROM HERE</h2>
			</div>
			<?php 
				$query1="SELECT * FROM themes";
				$result1=mysqli_query($conn,$query1);
				while($row=mysqli_fetch_array($result1))
				{
			?>
			<a href="proc/check_proc.php?check=1&theme=<?php echo $row[0] ?>">
			<div class="col-md-4 col-sm-4 temp">
				<img src="<?php echo $row[3]; ?>" class="img-responsive" alt="theme image not found">
			</div>
			</a>
			<?php } ?>
			<div class="col-md-12 col-sm-12">
				<p>Select One Of The Theme From here</p>
			</div>
		</div>
	</div>
</div>
<?php
 }
?>
<!-- pricing section -->
<div id="pricing">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<h2>Our Pricing</h2>
			</div>
			<div class="col-md-4 col-sm-6 col-xs-10">
				<div class="plan">
					<div class="plan-title">
						<h3>1 Month</h3>
						<small>$100 per month</small>
					</div>
					<ul>
						<li>10 GB STORAGE</li>
						<li>Host Your Site On own Domain</li>
						<li>ACCESS OUR PREMIUM THEMES</li>
					</ul>
					<a href="checkout.php"><button class="btn btn-warning">BUY</button></a>
				</div>
			</div>
			<div class="col-md-4 col-sm-6 col-xs-10">
				<div class="plan">
					<div class="plan-title">
						<h3>6 Months</h3>
						<small>$550 per 6 Months</small>
					</div>
					<ul>
						<li>100 GB STORAGE</li>
						<li>Host Your Site On own Domain</li>
						<li>ACCESS OUR PREMIUM THEMES</li>
					</ul>
					<a href="checkout.php"><button class="btn btn-warning">BUY</button></a>
				</div>
			</div>
			<div class="col-md-4 col-sm-6 col-xs-10">
				<div class="plan">
					<div class="plan-title">
						<h3>1 Year</h3>
						<small>$1100 per Year</small>
					</div>
					<ul>
						<li>1000 GB STORAGE</li>
						<li>Host Your Site On own Domain</li>
						<li>ACCESS OUR PREMIUM THEMES</li>
					</ul>
					<a href="checkout.php"><button class="btn btn-warning">BUY</button></a
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include("add-ons/footer.php");
}
else{
	header('location:login.php');
}
?>