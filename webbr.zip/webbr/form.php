<?php
	include('proc/connect.php');
	if(isset($_REQUEST['theme']))
    {
		$theme=$_REQUEST['theme'];
		$userid=$_SESSION['login_user'];
		$getuname="select*from user where u_id='$userid'";
		$getname= mysqli_query($conn,$getuname) or die(mysqli_error($conn));
		while($nrow= mysqli_fetch_object($getname))
		{
			$dirname= $nrow->email;
			$path='/xampp/htdocs/project1/usertemp/'.$dirname;
			if(!file_exists($path))
			{
				mkdir($path,0777,true);
			}
		}
	}
?>
<?php 
if(isset($_REQUEST['theme']))
	{
		$theme=$_REQUEST['theme'];
	}
	?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<title>form</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/css/font-awesome.min.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
</head>
<body>
<div class="container">
<div class="row">

	<div class="col-md-3  navbar-fixed-top" id="menu" class="list">
			<?php
				if(!isset($_REQUEST['site'])&&!isset($_REQUEST['menu'])&&!isset($_REQUEST['home'])&&!isset($_REQUEST['about'])&&!isset($_REQUEST['feature'])&&!isset($_REQUEST['contact'])&&!isset($_REQUEST['social'])&&!isset($_REQUEST['t']))
				{	
			?>
			<ul class="list-group">
				<a href="after_login.php"><li class="list-group-item btn btn-default"><span style="float:left; position:relative; top:3px;" class="fa fa-chevron-left"></span>HOME</li></a>
				<a href="form.php?site=1&theme=<?php echo $theme; ?>"><li class="list-group-item">Site-Identity<span class="fa fa-chevron-right"></span></li></a>
				<a href="form.php?menu=1&theme=<?php echo $theme; ?>"><li class="list-group-item">Menu-Name<span class="fa fa-chevron-right"></span></li></a>
				<a href="form.php?home=1&theme=<?php echo $theme; ?>"><li class="list-group-item">Home<span class="fa fa-chevron-right"></span></li></a>
				<a href="form.php?about=1&theme=<?php echo $theme; ?>"><li class="list-group-item">About<span class="fa fa-chevron-right"></span></li></a>
				<a href="form.php?feature=1&theme=<?php echo $theme; ?>"><li class="list-group-item">Features<span class="fa fa-chevron-right"></span></li></a>
				<a href="form.php?contact=1&theme=<?php echo $theme; ?>"><li class="list-group-item">Contacts<span class="fa fa-chevron-right"></span></li></a>
				<a href="form.php?social=1&theme=<?php echo $theme; ?>"><li class="list-group-item">Social-Media<span class="fa fa-chevron-right"></span></li></a>
				<a href="form.php?t=1&theme=<?php echo $theme; ?>"><li class="list-group-item">Themes<span class="fa fa-chevron-right"></span></li></a>
			</ul>
			<?php } ?>
			<form action="proc/edit_proc.php?theme=<?php echo $theme; ?>" method="POST" enctype="multipart/form-data">
			<?php
				if(isset($_REQUEST['site']))
				{	
			?>
			<label for="site_name">site name</label>
			<input type="text" name="site_name" class="form-control" id="site_name" />
			
			<input type="submit" class="btn btn-md btn-primary" id="site_sub" name="site_sub" value="save"/>
			<a href="form.php?theme=<?php echo $theme; ?>"><input type="button" class="btn btn-md btn-default" id="edit_sub" value="back"/></a>
			<?php } ?>
			<?php
				if(isset($_REQUEST['menu']))
				{	
			?>
			<label for="nav1">nav1</label>
			<input type="text" name="nav1" class="form-control" id="nav1" value="home" />
			<label for="nav2">nav2</label>
			<input type="text" name="nav2" class="form-control" id="nav2" value="about us" />
			<label for="nav3">nav3</label>
			<input type="text" name="nav3" class="form-control" id="nav3" value="features" />
			<label for="nav4">nav4</label>
			<input type="text" name="nav4" class="form-control" id="nav4" value="contact us" />
			<a href="form.php?theme=<?php echo $theme; ?>"><input type="button" class="btn btn-md btn-default" id="edit_sub" value="back"/></a>
			<input type="submit" class="btn btn-md btn-primary" id="menu_sub" name="menu_sub" value="save"/>
			<?php } ?>
			<?php
				if(isset($_REQUEST['home']))
				{	
			?>
			<label for="home_heading">home heading</label>
			<input type="text" name="home_heading" class="form-control" id="home_heading" />
			<label for="home_details">home details</label>
			<textarea name="home_details" class="form-control" id="home_details"></textarea>
			<label for="home_bg">home background</label>
			<input type="file" name="home_bg" class="form-control" id="home_bg" />
			<a href="form.php?theme=<?php echo $theme; ?>"><input type="button" class="btn btn-md btn-default" id="edit_sub" value="back"/></a>
			<input type="submit" class="btn btn-md btn-primary" id="home_sub" name="home_sub" value="save"/>
			<?php } ?>
			<?php
				if(isset($_REQUEST['about']))
				{	
			?>
			<label for="about_heading">about heading</label>
			<input type="text" name="about_heading" class="form-control" id="about_heading" />
			<label for="about_details">about details</label>
			<textarea name="about_details" class="form-control" id="about_details"></textarea>
			<label for="about_bg">about background</label>
			<input type="file" name="about_bg" class="form-control" id="about_bg" />
			<label for="about_img">about image</label>
			<input type="file" name="about_img" class="form-control" id="about_img" />
			<a href="form.php?theme=<?php echo $theme; ?>"><input type="button" class="btn btn-md btn-default" id="edit_sub" value="back"/></a>
			<input type="submit" class="btn btn-md btn-primary" id="about_sub" name="about_sub" value="save"/>
			<?php } ?>
			<?php
				if(isset($_REQUEST['feature']))
				{	
			?>
			<label for="feature_heading">feature heading</label>
			<input type="text" name="feature_heading" class="form-control" id="feature_heading" />
			<label for="feature_details">feature details</label>
			<textarea name="feature_details" class="form-control" id="feature_details"></textarea>
			<label for="feature_bg">feature background</label>
			<input type="file" name="feature_bg" class="form-control" id="feature_bg" />
			<label for="feature_img">feature image</label>
			<input type="file" name="feature_img" class="form-control" id="feature_img" />
			<a href="form.php?theme=<?php echo $theme; ?>"><input type="button" class="btn btn-md btn-default" id="edit_sub" value="back"/></a>
			<input type="submit" class="btn btn-md btn-primary" id="feature_sub" name="feature_sub" value="save"/>
			<?php } ?>
			<?php
				if(isset($_REQUEST['contact']))
				{	
			?>
			<label for="contact_number">contact number</label>
			<input type="text" name="contact_number" class="form-control" pattern="[0-9]{10}$" id="contact_number" />
			<label for="contact_email">E-mail</label>
			<input type="text" name="contact_email" class="form-control" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" id="contact_email" />
			<label for="contact_address">contact address</label>
			<textarea name="contact_address" class="form-control" id="contact_address"></textarea>
			<label for="contact_bg">contact background</label>
			<input type="file" name="contact_bg" class="form-control" id="contact_bg" />
			<a href="form.php?theme=<?php echo $theme; ?>"><input type="button" class="btn btn-md btn-default" id="edit_sub" value="back"/></a>
			<input type="submit" class="btn btn-md btn-primary" id="contact_sub" name="contact_sub" value="save"/>
			<?php } ?>
			<?php
				if(isset($_REQUEST['social']))
				{	
			?>
			<label for="fb_url">facebook URL</label>
			<input type="text" name="fb_url" class="form-control" id="fb_url" />
			<label for="tweet_url">twitter URL</label>
			<input type="text" name="twitter_url" class="form-control" id="tweet_url" />
			<label for="gplus_url">google+ URL</label>
			<input type="text" name="gplus_url" class="form-control" id="gplus_url" />
			<label for="insta_url">instagram URL</label>
			<input type="text" name="insta_url" class="form-control" id="insta_url" />
			<a href="form.php?theme=<?php echo $theme; ?>"><input type="button" class="btn btn-md btn-default" id="edit_sub" value="back"/></a>
			<input type="submit" class="btn btn-md btn-primary" id="social_sub" name="social_sub" value="save"/>
			<?php } ?>
			<?php
				if(isset($_REQUEST['t']))
				{	
			?>
			<?php 
				$query1="SELECT * FROM themes";
				$result1=mysqli_query($conn,$query1);
				while($row=mysqli_fetch_array($result1))
				{
					
			?>
			<label for="img"><?php echo $row[1];?></label>
			<a href="proc/edit_proc.php?t_sub=<?php echo $row[0];?>"><img src="<?php echo $row[3];?>" class="img-responsive" alt="" /></a>
			<?php } ?>
			<a href="form.php?theme=<?php echo $theme; ?>"><input type="button" class="btn btn-md btn-default" id="edit_sub" value="back"/></a>
			<?php } ?>
			</form>
	</div>
	<?php
		function recurse_copy($src,$dst) { 
    $dir = opendir($src); 
    @mkdir($dst); 
    while(false !== ( $file = readdir($dir)) ) { 
        if (( $file != '.' ) && ( $file != '..' )) { 
            if ( is_dir($src . '/' . $file) ) { 
                recurse_copy($src . '/' . $file,$dst . '/' . $file); 
            } 
            else { 
                copy($src . '/' . $file,$dst . '/' . $file); 
            } 
        } 
    } 
    closedir($dir); 
} 
	?>
	<?php 
		
		$userid = $_SESSION['login_user'];
		$getuname = "select * from user where u_id = '$userid'";
		$getname = mysqli_query($conn,$getuname) or die(mysqli_error($conn));
		while($nrow = mysqli_fetch_object($getname)){
				$dirname = $nrow->email;
				$query="select * from themes where theme_id=".$_REQUEST['theme']."";
				$result=mysqli_query($conn,$query);
				while($row= mysqli_fetch_array($result))
				{
						
						$path = '/xampp/htdocs/project1/usertemp/'.$dirname.'/'.$row[1].'/';
						$path1 = '/project1/usertemp/'.$dirname.'/'.$row[1].'/';
						$path2 = 'usertemp/'.$dirname.'/'.$row[1].'/home.php';
						$src = $row[2];
				}
			if(!file_exists($path)){
				recurse_copy($src, $path);
			}
			
		}
		?>
			<figure>
				<div id="theme" class="col-lg-9 col-lg-offset-3">
					<iframe src="<?php echo $path2; ?>" width="900px" height="2725px"></iframe>
				</div>
			</figure>
</div>
</div>

</body>
</html>