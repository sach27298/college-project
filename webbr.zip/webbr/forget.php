<?php
include("addons/header.php");

if(isset($_REQUEST['error'])){?>
<div class="container">
	<div class="row">
		<div class="col-md-4 col-sm-4"></div>
		<div class="col-md-4 col-sm-4">
			<div class="alert alert-danger">
				<p><i class="fa fa-info-circle"></i>password and confirm password doesn't matched.</p>
			</div>
		</div>
		<div class="col-md-4 col-sm-4"></div>
	</div>
</div>
<?php } ?>
<!-- register section -->
<div id="contact">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<h2>FORGET PASSWORD</h2>
			</div>
			<form action="proc/forget_proc.php" method="POST" enctype="multipart/form-data">
				<div class="col-md-1 col-sm-1"></div>
				<div class="col-md-10 col-sm-10">
				<?php
						if(!isset($_REQUEST['p']))
						{
					?>
					<div class="col-md-12 col-sm-12">
						<input name="email" type="email" class="form-control" id="email" placeholder="Email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required>
						<div class="col-md-offset-8 col-sm-offset-8">
						<input name="for_sub" type="submit" class="form-control" id="login" value="SUBMIT">
					</div>
				  	</div>
					<?php
						}
						if(isset($_REQUEST['p']))
						{
					?>
					<div class="col-md-12 col-sm-12">
						<input name="password" type="password" class="form-control" id="password" placeholder="Password" pattern="(?=.*\d)(?=.[a-z]).{8,16}$" title="must contain at least one number and lowercase letters, and at least min. 8 and max 16 characters" required>
				  	</div>
					<div class="col-md-12 col-sm-12">
						<input name="c_password" type="password" class="form-control" id="password" placeholder="Confirm Password" required>
				  	</div>
					<div class="col-md-4 col-md-offset-8 col-sm-offset-8 col-sm-4">
						<input name="chngepwd_sub" type="submit" class="form-control" id="login" value="CHANGE PASSWORD">
					</div>
					<?php } ?>
				</div>
				<div class="col-md-1 col-sm-1"></div>
			</form>
		</div>
	</div>
</div>
<?php
include("add-ons/footer.php");
?>