<?php
include("add-ons/header.php");
?>
<!-- home section -->
<div id="home">
	<div class="container">
		<div class="row">
			<div class="col-md-offset-6 col-md-6 col-sm-offset-6 col-sm-6">
				<h2>Welcome to</h2>
				<h1><b id="webbr">WEBBR</b> a webpage builder</h1>
				<!--<h4>webbr is develop for creating webpages without any coding.</h4>-->
				<a href="register.php" class="btn btn-default smoothScroll">GET STARTED</a>
			</div>
		</div>
	</div>
</div>
<?php
include("add-ons/footer.php");
?>