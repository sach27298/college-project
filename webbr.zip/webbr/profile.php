<?php
	$conn=mysqli_connect('localhost','root','','webbr');
	session_start();
?>

<!DOCTYPE HTML>
<html>
<head>
	<title>WEBBR</title>
		<!-- stylesheet css -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/css/font-awesome.css">
	<link rel="stylesheet" href="css/nivo-lightbox.css">
	<link rel="stylesheet" href="css/nivo_themes/default/default.css">
	<link rel="stylesheet" href="css/style.css">
	<!-- google web font css -->
	<link href='http://fonts.googleapis.com/css?family=Raleway:400,300,600,700' rel='stylesheet' type='text/css'>
</head>
<body>
<div class="navbar navbar-default" role="navigation">
	<div class="container">
		<div class="navbar-header">
			<button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
				<span class="icon icon-bar"></span>
				<span class="icon icon-bar"></span>
				<span class="icon icon-bar"></span>
			</button>
			<a href="#home" class="navbar-brand smoothScroll">WEBBR</a>
		</div>
		<div class="collapse navbar-collapse">
			<ul class="nav navbar-nav navbar-right">
				<li><a href="after_login.php" class="smoothScroll">HOME</a></li>
				<li><a href="proc/logout_proc.php" class="smoothScroll"><span class="fa fa-sign-out"></span>LOGOUT</a></li>
			</ul>
		</div>
	</div>
</div>
<?php
if(isset($_REQUEST['s']))
 { ?>
	<div class="container">
		<div class="row">
			<div class="col-md-4 col-sm-4"></div>
			<div class="col-md-4 col-sm-4">
				<div class="alert alert-success">
					<p><i class="fa fa-info-circle"></i> Your details updated Successfully!!</p>
				</div>
			</div>
			<div class="col-md-4 col-sm-4"></div>
		</div>
	</div>
 <?php }
?>
<?php
if(isset($_REQUEST['error']))
{ ?>
<div class="container">
	<div class="row">
		<div class="col-md-4 col-sm-4"></div>
		<div class="col-md-4 col-sm-4">
			<div class="alert alert-danger">
				<p><i class="fa fa-info-circle"></i>password and confirm password doesn't match.</p>
			</div>
		</div>
		<div class="col-md-4 col-sm-4"></div>
	</div>
</div>
<?php } ?>
<?php 
	if(isset($_REQUEST['dp']))
	{
?>
	<div class="row" id="mymodal" role="dialog">
		<div class="modal-dialog">
			<!--modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<a href="profile.php"><button type="button" class="close" data-dismiss="modal">&times;</button></a>
					<h4>Change Profile Picture</h4>
				</div>
				<div class="modal-body">
					<form action="proc/profile_proc.php" method="POST" enctype="multipart/form-data">
						<input type="file" class="form-control" name="u_dp" title="profile picture size=2MB only" required/>
					
				</div>
				<div class="modal-footer">
					<input type="submit" name="up_dp_sub" class="btn btn-primary btn-md" value="submit"/>
					<a href="profile.php"><input type="button" class="btn btn-default btn-md" data-dismiss="modal" value="Close"></a>
					</form>
				</div>
			</div>
			</div>
		</div>
	
	</div>
	<?php }?>
<?php 
	if(isset($_REQUEST['p']))
	{
?>
	<div class="row" id="mymodal" role="dialog">
		<div class="modal-dialog">
			<!--modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<a href="profile.php"><button type="button" class="close" data-dismiss="modal">&times;</button></a>
					<h4>Change Password</h4>
				</div>
				<div class="modal-body">
					<form action="proc/profile_proc.php" method="POST">
						<div class="col-md-6 col-sm-6">
						<input name="password" type="password" class="form-control" id="password" placeholder="Password" pattern="(?=.*\d)(?=.[a-z]).{8,16}$" title="must contain at least one number and lowercase letters, and at least min. 8 and max 16 characters" required>
				  	</div>
					<div class="col-md-6 col-sm-6">
						<input name="c_password" type="password" class="form-control" id="password" placeholder="Confirm Password" pattern="(?=.*\d)(?=.[a-z]).{8,16}$" title="must contain at least one number and lowercase letters, and at least min. 8 and max 16 characters" required>
				  	</div>
				</div>
				<div class="modal-footer">
					<div class="col-md-12 col-sm-12">
					<input type="submit" name="change_pwd" class="btn btn-primary btn-md form-control" value="change password"/>
					</div>
					</form>
				</div>
			</div>
		</div>
	
	</div>
	<?php }?>
<div id="contact">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<h2>PROFILE</h2>
			</div>
			<form action="proc/profile_proc.php" method="POST">
				<div class="col-md-1 col-sm-1"></div>
				<div class="col-md-10 col-sm-10">
				
					<div class="col-md-12 col-sm-12">
						
						<?php $query = "select image from user where u_id=$_SESSION[login_user]";
												   $result=mysqli_query($conn,$query);
												   while($row=mysqli_fetch_array($result))
												   {
													?>
												<img class="dp" src="<?php echo $row[0]; ?>" alt="dp"/>	
												<?php	}?>
				  	</div>
					<div class="col-md-6 col-sm-6">
						<a href="profile.php?dp=1"><input name="change_dp" type="button" class="form-control" id="change_dp" value="CHANGE PROFILE PICTURE"></a>
				  	</div>
					<div class="col-md-6 col-sm-6">
						<a href="profile.php?p=1"><input name="change_pwd" type="button" class="form-control" id="change_pwd" value="CHANGE PASSWORD"></a>
				  	</div>
					<div class="col-md-12 col-sm-12">
						<input name="name" type="text" class="form-control" id="name" placeholder="Name" value=<?php $query = "select name from user where u_id=$_SESSION[login_user]";
												   $result=mysqli_query($conn,$query);
												   while($row=mysqli_fetch_array($result))
												   {
													echo $row[0];
													}?> required>
				  	</div>
					<div class="col-md-6 col-sm-6">
						<input name="email" type="email" class="form-control" id="email" placeholder="Email" value="<?php $query = "select email from user where u_id=$_SESSION[login_user]";
												   $result=mysqli_query($conn,$query);
												   while($row=mysqli_fetch_array($result))
												   {
													echo $row[0];
													}?>" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required>
				  	</div>
					<div class="col-md-6 col-sm-6">
						<input name="mobile_no" type="text" class="form-control" id="mobile_no" placeholder="Mobile Number" value="<?php $query = "select phone_number from user where u_id=$_SESSION[login_user]";
												   $result=mysqli_query($conn,$query);
												   while($row=mysqli_fetch_array($result))
												   {
													echo $row[0];
													}?>" pattern="[0-9]{10}$" required>
				  	</div>
					<div class="col-md-6 col-sm-6">
						<a href="after_login.php"><input name="back" type="button" class="form-control" id="change_dp" value="BACK HOME"></a>
				  	</div>
					<div class="col-md-6 col-sm-6">
						<input name="pro_sub" type="submit" class="form-control" id="submit" value="SAVE">
					</div>
				</div>
				<div class="col-md-1 col-sm-1"></div>
			</form>
		</div>
	</div>
</div>
<?php
include("add-ons/footer.php");
?>