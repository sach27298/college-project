<?php
include('proc/connect.php');
?>
<!DOCTYPE HTML>
<html>
<head>
	<title>WEBBR</title>
		<!-- stylesheet css -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/css/font-awesome.css">
	<link rel="stylesheet" href="css/nivo-lightbox.css">
	<link rel="stylesheet" href="css/nivo_themes/default/default.css">
	<link rel="stylesheet" href="css/style.css">
	<!-- google web font css -->
	<link href='http://fonts.googleapis.com/css?family=Raleway:400,300,600,700' rel='stylesheet' type='text/css'>
</head>
<body data-spy="scroll" data-target=".navbar-collapse">

<!-- navigation -->
<div class="navbar navbar-default" role="navigation">
	<div class="container">
		<div class="navbar-header">
			<button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
				<span class="icon icon-bar"></span>
				<span class="icon icon-bar"></span>
				<span class="icon icon-bar"></span>
			</button>
			<a href="#home" class="navbar-brand smoothScroll">WEBBR</a>
		</div>
		<div class="collapse navbar-collapse">
			<ul	class="nav navbar-nav navbar-right">
			<li><a href="profile.php" class="smoothScroll"><?php $query = "select image,name from user where u_id=$_SESSION[login_user]";
												   $result=mysqli_query($conn,$query);
												   while($row=mysqli_fetch_array($result))
												   {
													?>
												<img class="profile" src="<?php echo $row[0]; ?>" alt="dp"/>	
												<?php echo $row[1];}?>
			</a></li>
			<li><a href="proc/logout_proc.php" class="smoothScroll"><span class="fa fa-sign-out"></span>LOGOUT</a></li>
		</ul>
		</div>
	</div>
</div>
<div id="contact">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<h2>GIVE NAME TO YOUR SITE</h2>
			</div>
			<form action="<?php
						if(isset($_REQUEST['theme']))
						{
							$theme=$_REQUEST['theme'];
							echo "proc/edit_proc.php?theme=".$theme."";
						}
						else 
						{
							echo "proc/edit_proc.php";
						}
						?>" method="POST">
				<div class="col-md-1 col-sm-1"></div>
				<div class="col-md-10 col-sm-10">
					<div class="col-md-12 col-sm-12">
						<input name="sitename" type="text" class="form-control" id="sitename" placeholder="Site Name" required>
	    	  	  	</div>
					<div class="col-md-4 col-md-offset-8 col-sm-4 col-sm-offset-8">
						<input name="name_sub" type="submit" class="form-control" id="submit" value="SAVE">
					</div>
				</div>
				<div class="col-md-1 col-sm-1"></div>
			</form>
		</div>
	</div>
</div>

<?php
include("add-ons/footer.php");
?>