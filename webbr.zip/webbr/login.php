<?php
include("add-ons/header.php");
?>
<?php
if(isset($_REQUEST['s']))
 {
	if($_REQUEST['s']==1)
	{
 ?>
	<div class="container">
		<div class="row">
			<div class="col-md-4 col-sm-4"></div>
			<div class="col-md-4 col-sm-4">
				<div class="alert alert-success">
					<p><i class="fa fa-info-circle"></i> You Have Registered Successfully!!</p>
				</div>
			</div>
			<div class="col-md-4 col-sm-4"></div>
		</div>
	</div>
 <?php }
	if($_REQUEST['s']==2)
	{
 ?>
 <div class="container">
		<div class="row">
			<div class="col-md-4 col-sm-4"></div>
			<div class="col-md-4 col-sm-4">
				<div class="alert alert-success">
					<p><i class="fa fa-info-circle"></i> Password Change Successfully!!</p>
				</div>
			</div>
			<div class="col-md-4 col-sm-4"></div>
		</div>
	</div>
 <?php
 }}
?>
<!-- contact section -->
<div id="contact">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<h2>LOGIN</h2>
			</div>
			<form action="proc/login_proc.php" method="POST">
				<div class="col-md-1 col-sm-1"></div>
				<div class="col-md-10 col-sm-10">
					<div class="col-md-6 col-sm-6">
						<input name="email" type="email" class="form-control" id="email" placeholder="Email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" title=""  required>
				  	</div>
					<div class="col-md-6 col-sm-6">
						<input name="password" type="password" class="form-control" id="password" placeholder="Password" pattern="(?=.*\d)(?=.[a-z]).{8,16}$" title="must contain at least one number and lowercase letters, and at least min. 8 and max 16 characters" required>
				  	</div>
					<div class="col-md-8 col-sm-8">
						<a href="forget.php"><p>Forget Your Password?</p></a>
					</div>
					<div class="col-md-4 col-sm-4">
						<input name="log_sub" type="submit" class="form-control" id="submit" value="LOGIN">
					</div>
				</div>
				<div class="col-md-1 col-sm-1"></div>
			</form>
		</div>
	</div>
</div>
<?php
if(isset($_REQUEST['error']))
{ ?>
<div class="container">
	<div class="row">
		<div class="col-md-4 col-sm-4"></div>
		<div class="col-md-4 col-sm-4">
			<div class="alert alert-danger">
				<p><i class="fa fa-info-circle"></i> email or password is uncorrect!!</p>
			</div>
		</div>
		<div class="col-md-4 col-sm-4"></div>
	</div>
</div>
<?php } ?>
<?php
include("add-ons/footer.php");
?>