<?php
include("add-ons/header.php");

if(isset($_REQUEST['f']))
 {
 ?>
	<div class="container">
		<div class="row">
			<div class="col-md-4 col-sm-4"></div>
			<div class="col-md-4 col-sm-4">
				<div class="alert alert-success">
					<p><i class="fa fa-info-circle"></i> Thanks for your feedback!!</p>
				</div>
			</div>
			<div class="col-md-4 col-sm-4"></div>
		</div>
	</div>
<?php } ?>
<!-- contact section -->
<div id="contact">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<h2>Keep in touch</h2>
			</div>
			<form action="proc/feedback_proc.php" method="post">
				<div class="col-md-1 col-sm-1"></div>
				<div class="col-md-10 col-sm-10">
					<div class="col-md-6 col-sm-6">
						<input name="name" type="text" class="form-control" id="name" placeholder="Name" required>
				  	</div>
					<div class="col-md-6 col-sm-6">
						<input name="email" type="email" class="form-control" id="email" placeholder="Email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" title=""  required>
				  	</div>
                    <div class="col-md-12 col-sm-12">
						<input name="subject" type="text" class="form-control" id="subject" placeholder="Subject" required>
	    	  	  	</div>
					<div class="col-md-12 col-sm-12">
						<textarea name="msg" rows="5" class="form-control" id="message" placeholder="Message" required></textarea>
					</div>
					<div class="col-md-8 col-sm-8">
						<p>we give response to you as soon as possible.</p>
					</div>
					<div class="col-md-4 col-sm-4">
						<input name="feed_submit" type="submit" class="form-control" id="submit" value="SEND MESSAGE">
					</div>
				</div>
				<div class="col-md-1 col-sm-1"></div>
			</form>
		</div>
	</div>
</div>
<?php
include("add-ons/footer.php");
?>