<?php
include("add-ons/header.php");
?>
<?php
if(isset($_REQUEST['error']))
{  if($_REQUEST['error']==2){?>
<div class="container">
	<div class="row">
		<div class="col-md-4 col-sm-4"></div>
		<div class="col-md-4 col-sm-4">
			<div class="alert alert-danger">
				<p><i class="fa fa-info-circle"></i>password and confirm password doesn't matched.</p>
			</div>
		</div>
		<div class="col-md-4 col-sm-4"></div>
	</div>
</div>

<?php 
}
if($_REQUEST['error']==1){ ?>
<div class="container">
	<div class="row">
		<div class="col-md-4 col-sm-4"></div>
		<div class="col-md-4 col-sm-4">
			<div class="alert alert-danger">
				<p><i class="fa fa-info-circle"></i>User not exist!,You need to register first.</p>
			</div>
		</div>
		<div class="col-md-4 col-sm-4"></div>
	</div>
</div>
<?php } }?>
<!-- register section -->
<div id="contact">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<h2>REGISTRATION</h2>
			</div>
			<form action="proc/reg_proc.php" method="POST" enctype="multipart/form-data">
				<div class="col-md-1 col-sm-1"></div>
				<div class="col-md-10 col-sm-10">
					<div class="col-md-12 col-sm-12">
						<input name="name" type="text" class="form-control" id="name" placeholder="Name" required>
				  	</div>
					<div class="pp"><label>Profile Picture</label></div>
					<div class="col-md-12 col-sm-12">
						<input type="file" name="dp" class="form-control" id="dp" title="Profile Picture:size=2MB only" required>
				  	</div>
					<div class="col-md-6 col-sm-6">
						<input name="mobile_no" type="text" class="form-control" id="mobile_no" placeholder="Mobile Number" pattern="[0-9]{10}$" required>
				  	</div>
					<div class="col-md-6 col-sm-6">
						<input name="email" type="email" class="form-control" id="email" placeholder="Email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required>
				  	</div>
					<div class="col-md-6 col-sm-6">
						<input name="password" type="password" class="form-control" id="password" placeholder="Password" pattern="(?=.*\d)(?=.[a-z]).{8,16}$" title="must contain at least one number and lowercase letters, and at least min. 8 and max 16 characters" required>
				  	</div>
					<div class="col-md-6 col-sm-6">
						<input name="c_password" type="password" class="form-control" id="password" placeholder="Confirm Password" required>
				  	</div>
					<div class="col-md-12 col-sm-12">
						<select name="s_que" class="form-control" required>
							<option>Security Question</option>
							<option value="What Is Your First Mobile Number?">What Is Your First Mobile Number?</option>
							<option value="Who Is Your Best Friend?">Who Is Your Best Friend?</option>
							<option value="What Is Your Nick Name?">What Is Your Nick Name?</option>
						</select>
	    	  	  	</div>
					<div class="col-md-12 col-sm-12">
						<input name="s_ans" type="text" class="form-control" id="Security_Answer" placeholder="Security Answer" required>
	    	  	  	</div>
					<div class="col-md-8 col-md-offset-4 col-sm-offset-4 col-sm-8">
						<input name="reg_sub" type="submit" class="form-control" id="submit" value="REGISTRATION">
					</div>
				</div>
				<div class="col-md-1 col-sm-1"></div>
			</form>
		</div>
	</div>
</div>
<?php
include("add-ons/footer.php");
?>