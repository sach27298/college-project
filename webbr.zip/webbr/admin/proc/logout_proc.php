<?php
	session_start();
	session_unset('login_admin');
	session_destroy();
	header('location:../login.php');
?>