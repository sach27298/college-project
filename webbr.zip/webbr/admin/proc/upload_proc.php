<?php
include('connect.php');
if(isset($_POST['theme_sub']))
{
	$t_name=$_POST['theme_name'];
	$file_name=($_FILES['ufile']['name']);
	echo $file_name;	
	//$file_name = $_POST['ufile'];
	//$random_digit=rand(0000,9999);
	$new_file_name=$t_name.".zip";
	$new_file_name1=$t_name;
	$path= 'c:/xampp/htdocs/project1/themes/';
	
	mkdir($path.$new_file_name1, 077, true);
	
	$path1='c:/xampp/htdocs/project1/themes/'.$new_file_name.'';
	$path2='c:/xampp/htdocs/project1/themes/'.$new_file_name1.'';
	if($file_name != null)
	{
		if(copy($_FILES['ufile']['tmp_name'], $path1))
		{
			echo "Successfully updated<BR/>"; 
			echo "File Renamed to: ".$new_file_name." for processing.<BR/>"; 
			echo "File Size :".$_FILES['ufile']['size']."<BR/>"; 
			$pic = file_get_contents($_FILES["dp"]["tmp_name"]);
		$picdir = "/xampp/htdocs/project1/";
		$picdir1 = "thumb_img/";
		$picdir2 = "/xampp/htdocs/project1/thumb_img/";
		$picdir3 = "c:/xampp/htdocs/project1/thumb_img/";
		mkdir($picdir.$picdir1, 077, true);
		$dpimage = $picdir1.basename($_FILES["dp"]["name"]);
		$dpimage1 = $picdir3.basename($_FILES["dp"]["name"]);
		$uploadok = 1;
		$imagefiletype = pathinfo($dpimage,PATHINFO_EXTENSION);

		
		if($imagefiletype != "jpg" && $imagefiletype != "png" && $imagefiletype != "jpeg"){

			echo "Sorry, only JPG, JPEG and PNG file format allowed";
			$uploadok = 0;

		}

		if($uploadok == 0){
          echo "There is Some problem with your image or form data data, please recheck and try again.";
		}else {

			if(move_uploaded_file($_FILES["dp"]["tmp_name"], $picdir2.$_FILES["dp"]["name"])){
                   
				echo "file uploaded successfully";
				
				
		//mysqli_query($conn,$query) or die(mysqli_error($conn));

			}else {
				echo "there was an error to register and uploading your image";
			}

		}

			$zip= new ZipArchive;
	if($zip->open($path1)===TRUE)
	{
		$zip->open($path1);
		//$query="select * from themes where theme_name= '$t_name'";
		//$result=mysqli_query($conn,$query);
		//while($row=mysqli_fetch_array($result))
		//{
		//	$url=$row[2];
		//}
	
		$zip->extractTo($path2);
		//zip_close($zip);
		$zip->close();	
		echo 'ok';
		$path3= 'c:/xampp/htdocs/project1/themes/'.$new_file_name1.'/';
		$query="insert into themes values('','$t_name','$path3','$dpimage')";
		$result=mysqli_query($conn,$query);
		header('location:../index.php');
	}
	else
	{
		echo 'falied to extract';
	}
		}
	else
	{
		echo "Error";
	}
	}

	

}


	
?>