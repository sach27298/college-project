<?php
$conn = mysqli_connect("localhost","root","","webbr");
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<title>ADMIN PANEL</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" media="all" />
</head>
<body>
<div id="contact">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<h2>ADMIN PANEL &nbsp;&nbsp;LOGIN</h2>
			</div>
			<form action="proc/login_proc.php" method="POST">
				<div class="col-md-1 col-sm-1"></div>
				<div class="col-md-10 col-sm-10">
					<div class="col-md-6 col-sm-6">
						<input name="email" type="email" class="form-control" id="email" placeholder="Email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" title=""  required>
				  	</div>
					<div class="col-md-6 col-sm-6">
						<input name="password" type="password" class="form-control" id="password" placeholder="Password" required>
				  	</div>
					<div class="col-md-8 col-sm-8">
						<p>Forget Your Password?</p>
					</div>
					<div class="col-md-4 col-sm-4">
						<input name="log_sub" type="submit" class="form-control" id="submit" value="LOGIN">
					</div>
				</div>
				<div class="col-md-1 col-sm-1"></div>
			</form>
		</div>
	</div>
</div>
<?php
if(isset($_REQUEST['error']))
{ ?>
<div class="container">
	<div class="row">
		<div class="col-md-4 col-sm-4"></div>
		<div class="col-md-4 col-sm-4">
			<div class="alert alert-danger">
				<p><i class="fa fa-info-circle"></i>email or password is uncorrect!!</p>
			</div>
		</div>
		<div class="col-md-4 col-sm-4"></div>
	</div>
</div>
<?php } ?>
</body>
</html>