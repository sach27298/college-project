<?php
include('../proc/connect.php');
if(isset($_SESSION['login_admin']))
{
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<title>ADMIN PANEL</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" media="all" />
</head>
<body>
<div class="navbar navbar-inverse" role="navigation">
	<div class="container">
		<div class="navbar-header">
			<a href="#home" class="navbar-brand smoothScroll">WEBBR</a>
		</div>
		<ul class="nav navbar-nav navbar-right">
				<li><a href="#" class="navbar-brand smoothScroll">Welcome To Admin Panel <?php $query = "select name from admin where admin_id=$_SESSION[login_admin]";
			$result=mysqli_query($conn,$query);
			while($row=mysqli_fetch_array($result))
			{
				echo $row[0];
			}?></a></li>
				<li><a href="proc/logout_proc.php" class="smoothScroll"><span class="fa fa-sign-out"></span>LOGOUT</a></li>
		</ul>
	</div>
</div>
<div class="container-fluid">
<div class="row">
	<aside class="col-lg-2 col-sm-3" id="menu">
		<h3 class="text-center">manage website</h3>
			<ul class="list-group">
				<a href="index.php"><li class="list-group-item">USED THEMES<span class="fa fa-chevron-right"></span></li></a>
				<a href="index.php?user=1"><li class="list-group-item">USERS<span class="fa fa-chevron-right"></span></li></a>
				<a href="index.php?theme=1"><li class="list-group-item">THEMES<span class="fa fa-chevron-right"></span></li></a>
				<a href="index.php?feedback=1"><li class="list-group-item">FEEDBACK<span class="fa fa-chevron-right"></span></li></a>
				<a href="index.php?admin=1"><li class="list-group-item">ADMIN<span class="fa fa-chevron-right"></span></li></a>
				<a href="index.php?add=1"><li class="list-group-item">ADD NEW THEME<span class="fa fa-chevron-right"></span></li></a>
			</ul>
	</aside>
	<article class="col-lg-10 col-sm-9" id="main">
		<?php 
			if(!isset($_REQUEST['user'])&&!isset($_REQUEST['theme'])&&!isset($_REQUEST['feedback'])&&!isset($_REQUEST['admin'])&&!isset($_REQUEST['add']))
			{
		?>
		<div class="home">
		<h2>USED THEMES</h2>
		<?php 
				$query1="SELECT * FROM themes";
				$result1=mysqli_query($conn,$query1);
				while($row=mysqli_fetch_array($result1))
				{
			?>
			<div class="col-md-4 col-sm-6">
			<div class="thumbnail">
				<img src="<?php echo '../'.$row[3].''; ?>" class="img-responsive" alt="theme image not found">
				<p><?php echo $row[1]; ?></p>
				<p class="caption"><?php $query="select theme_id from edit where theme_id=".$row[0].""; 
										 $result=mysqli_query($conn,$query);
										 $num=mysqli_num_rows($result);
										 echo "Used:".$num;
										 $query2="select name from user where u_id IN(select u_id from edit where theme_id=".$row[0].")";
										 $result2=mysqli_query($conn,$query2);
										 while($row2=mysqli_fetch_array($result2))
										 {
											echo "</br>User:".$row2[0]."";
										 }
										?></p>
			</div>
			</div>
			<?php } ?>
		</div>
			<?php }?>
		<?php 
		if(isset($_REQUEST['user']))
		{ ?>
		<div class="user">
			<h1>USER</h1>
				<table class="table table-bordered text-center">
				<tr class="danger">
					<td class="">u_id</td>
					<td>name</td>
					<td>email</td>
					<td>phone_number</td>
					
					<td>option</td>
				</tr>
				<?php 
					if(isset($_REQUEST['id']))
					{
						$query2 = "delete from user where u_id=".$_REQUEST['id'];
						$result2 = mysqli_query($conn,$query2);
					}
					$query = "select u_id,name,email,phone_number from user";
					$result = mysqli_query($conn,$query);
					while($row=mysqli_fetch_array($result))
					{
						echo '<tr class=info>';
						echo '<td>'.$row[0].'</td>';
						echo '<td>'.$row[1].'</td>';
						echo '<td>'.$row[2].'</td>';
						echo '<td>'.$row[3].'</td>';
						echo '<td><a href="index.php?user=1&id='.$row['u_id'].'">delete</a></td>';
						echo '</tr>';
					}
				?>
				</table>
		</div>
		<?php } ?>
		
		<?php 
		if(isset($_REQUEST['theme']))
		{ ?>
		<div class="theme">
			<h1>THEMES</h1>
				<table class="table table-bordered text-center">
				<tr class="danger">
					<td>theme_id</td>
					<td>theme_name</td>
					<td>theme_url</td>
					<td>theme_image</td>
					
					<td>option</td>
				</tr>
				<?php 
					if(isset($_REQUEST['id']))
					{
						$query2 = "delete from themes where theme_id=".$_REQUEST['id'];
						$result2 = mysqli_query($conn,$query2);
					}
					$query = "select * from themes";
					$result = mysqli_query($conn,$query);
					while($row=mysqli_fetch_array($result))
					{
						echo '<tr class=info>';
						echo '<td>'.$row[0].'</td>';
						echo '<td>'.$row[1].'</td>';
						echo '<td>'.$row[2].'</td>';
						echo '<td>'.$row[3].'</td>';
						echo '<td><a href="index.php?theme=1&id='.$row['theme_id'].'">delete</a></td>';
						echo '</tr>';
					}
				?>
				</table>
		</div>
		<?php } ?>

		<?php 
		if(isset($_REQUEST['feedback']))
		{ ?>
		<div class="feedback">
			<h1>FEEDBACK</h1>
				<table class="table table-bordered text-center">
				<tr class="danger">
					<td>f_id</td>
					<td>name</td>
					<td>email</td>
					<td>subject</td>
					<td>message</td>
					<td>option</td>
				</tr>
				<?php 
					if(isset($_REQUEST['id']))
					{
						$query2 = "delete from feedback where f_id=".$_REQUEST['id'];
						$result2 = mysqli_query($conn,$query2);
					}
					$query = "select * from feedback";
					$result = mysqli_query($conn,$query);
					while($row=mysqli_fetch_array($result))
					{
						echo '<tr class=info>';
						echo '<td>'.$row[0].'</td>';
						echo '<td>'.$row[1].'</td>';
						echo '<td>'.$row[2].'</td>';
						echo '<td>'.$row[3].'</td>';
						echo '<td>'.$row[4].'</td>';
						echo '<td><a href="index.php?feedback=1&id='.$row['f_id'].'">delete</a></td>';
						echo '</tr>';
					}
				?>
				</table>
		</div>
		<?php } ?>
		
		<?php 
		if(isset($_REQUEST['admin']))
		{ ?>
		<div class="admin">
			<h1>ADMIN</h1>
				<table class="table table-bordered text-center">
				<tr class="danger">
					<td>admin_id</td>
					<td>name</td>
					<td>email</td>
				</tr>
				<?php 
					$query = "select admin_id,name,email from admin";
					$result = mysqli_query($conn,$query);
					while($row=mysqli_fetch_array($result))
					{
						echo '<tr class=info>';
						echo '<td>'.$row[0].'</td>';
						echo '<td>'.$row[1].'</td>';
						echo '<td>'.$row[2].'</td>';
						echo '</tr>';
					}
				?>
				</table>
		</div>
		<?php } ?>
		<?php 
		if(isset($_REQUEST['add']))
		{ ?>
		<div class="admin">
			<div id="contact">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<h2>ADD NEW THEME</h2>
			</div>
			<form action="proc/upload_proc.php" method="POST" enctype="multipart/form-data">
				<div class="col-md-1 col-sm-1"></div>
				<div class="col-md-10 col-sm-10">
					<div class="col-md-12 col-sm-12">
						<input name="theme_name" type="text" class="form-control" id="name" placeholder="Theme Name" required>
				  	</div>
					<div class="col-md-6 col-sm-6 text-left"><label>Theme URL</label></div>
					<div class="col-md-6 col-sm-6 text-left"><label>Theme Thumbnail</label></div>
					<div class="col-md-6 col-sm-6">
						<input type="file" name="ufile" class="form-control" id="dp" title="Profile Picture:size=2MB only" required>
				  	</div>
					<div class="col-md-6 col-sm-6">
						<input type="file" name="dp" class="form-control" id="dp" title="Profile Picture:size=2MB only" required>
				  	</div>
					<div class="col-md-4 col-md-offset-8 col-sm-offset-8 col-sm-4">
						<input name="theme_sub" type="submit" class="form-control" id="submit" value="UPLOAD">
					</div>
				</div>
				<div class="col-md-1 col-sm-1"></div>
			</form>
		</div>
	</div>
</div>
		</div>
		<?php } ?>
	</article>
</div>
</div>

<script src="js/bootstrap.min.js"></script>
</body>
</html>
<?php }

else{
	header('location:login.php');
}
?>