<?php
	session_start();
	session_unset('login_user');
	session_destroy();
	header('location:../login.php');
?>