<?php
include('connect.php');
$u_id=$_SESSION['login_user'];
if(isset($_REQUEST['check']))
{
	if(isset($_REQUEST['theme']))
	{
		$query = "select u_id,sitename from edit where u_id=".$_SESSION[login_user]."";
		$result=mysqli_query($conn,$query);
		$num=mysqli_num_rows($result);
		if($num>0)
		{
			header('location:../form.php?theme='.$_REQUEST['theme'].'');
		}
		else
		{
			header('location:../givename.php?theme='.$_REQUEST['theme'].'');
		}
	}
	else
	{
		$query = "select u_id,sitename from edit where u_id=".$_SESSION[login_user]."";
		$result=mysqli_query($conn,$query);
		$num=mysqli_num_rows($result);
		if($num>0)
		{
			header('location:../after_login.php');
		}
		else
		{
			header('location:../givename.php');
		}
	}
}
if(isset($_REQUEST['edit']))
{
	$query="select theme_id from edit where u_id=".$_SESSION['login_user']."";
	$result=mysqli_query($conn,$query);
	$num=mysqli_num_rows($result);
	if($num>0)
	{
		while($row=mysqli_fetch_array($result))
		{
			$theme=$row[0];
			header('location:../form.php?theme='.$theme.'');
		}
	}
	else
	{
		header('location:../after_login.php?error=1');
	}
}

if(isset($_REQUEST['del']))
{
	$query="delete from edit where u_id='$u_id'";
	$result=mysqli_query($conn,$query);
	header('location:../after_login.php?error=1');
}

if(isset($_REQUEST['see']))
{
	
}
?>