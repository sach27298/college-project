<?php
include('connect.php');

if(isset($_POST['reg_sub']))
{
	if($_POST['password']!=$_POST['c_password'])
	{
		header('location:../register.php?error=2');
	}
	else if($_POST['password']==$_POST['c_password'])
	{
		$name=$_POST['name'];
		$mobile_no=$_POST['mobile_no'];
		$email=$_POST['email'];
		$password=md5($_POST['password']);
		$s_que=$_POST['s_que'];
		$s_ans=$_POST['s_ans'];
	
		$pic = file_get_contents($_FILES["dp"]["tmp_name"]);
		$picdir = "/xampp/htdocs/project1/uploads/";
		$picdir1 = "uploads/";
		$dpimage = $picdir1.basename($_FILES["dp"]["name"]);
		$uploadok = 1;
		$imagefiletype = pathinfo($dpimage,PATHINFO_EXTENSION);

		
		if($imagefiletype != "jpg" && $imagefiletype != "png" && $imagefiletype != "jpeg"){

			echo "Sorry, only JPG, JPEG and PNG file format allowed";
			$uploadok = 0;

		}

		if($uploadok == 0){
          echo "There is Some problem with your image or form data data, please recheck and try again.";
		}else {

			if(move_uploaded_file($_FILES["dp"]["tmp_name"], $picdir.$_FILES["dp"]["name"])){
                   
				echo "file uploaded successfully";
				$query = "insert into user values('','$name','$email','$mobile_no','$dpimage','$password','$s_que','$s_ans')";
				
		mysqli_query($conn,$query) or die(mysqli_error($conn));

			}else {
				echo "there was an error to register and uploading your image";
			}

		}

		header('location:../login.php?s=1');
	}
	
}

?>
