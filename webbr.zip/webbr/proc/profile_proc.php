<?php
include('connect.php');
session_start();
if(isset($_POST['up_dp_sub']))
{
		$pic = file_get_contents($_FILES["u_dp"]["tmp_name"]);
		$picdir = "/xampp/htdocs/project1/uploads/";
		$picdir1 = "uploads/";
		$dpimage = $picdir1.basename($_FILES["u_dp"]["name"]);
		$uploadok = 1;
		$imagefiletype = pathinfo($dpimage,PATHINFO_EXTENSION);

		
		if($imagefiletype != "jpg" && $imagefiletype != "png" && $imagefiletype != "jpeg"){

			echo "Sorry, only JPG, JPEG and PNG file format allowed";
			$uploadok = 0;

		}

		if($uploadok == 0){
          echo "There is Some problem with your image or form data data, please recheck and try again.";
		}else 
		{

			if(move_uploaded_file($_FILES["u_dp"]["tmp_name"], $picdir.$_FILES["u_dp"]["name"]))
			{
                   
				$query = "update user set image='$dpimage' where u_id='$_SESSION[login_user]'";
				mysqli_query($conn,$query) or die(mysqli_error($conn));
				header('location:../profile.php?s=1');

			}
			else 
			{
				echo "there was an error to register and uploading your image";
			}

		}
}
if(isset($_POST['pro_sub']))
{
		$name=$_POST['name'];
		$mobile_no=$_POST['mobile_no'];
		$email=$_POST['email'];
		
		$query = "update user set name='$name',email='$email',phone_number='$mobile_no' where u_id='$_SESSION[login_user]'";
		
		$result=mysqli_query($conn,$query);
		
		header('location:../profile.php?s=1');
}

if(isset($_POST['change_pwd']))
{
	if($_POST['password']==$_POST['c_password'])
	{
		
		$pwd=$_POST['password'];
		$query = "update user set password='$pwd' where u_id='$_SESSION[login_user]'";
		
		$result=mysqli_query($conn,$query);
		
		header('location:../profile.php?s=1');
	}
	else
	{
		header('location:../profile.php?p=1&error=1');
	}
	
}
?>