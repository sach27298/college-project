<?php
include('connect.php');
if(isset($_POST['for_sub']))
{
	$email=$_POST['email'];
	
	$query="select u_id,email from user where email='$email'";
	$result=mysqli_query($conn,$query);
	$num=mysqli_num_rows($result);
	
	if($num>0)
	{
		$_SESSION['email']=$email;
		header('location:../forget.php?p=1');
	}
	else
	{
		header('location:../register.php?error=1');
	}
	
}
if(isset($_POST['chngepwd_sub']))
{
	$pwd=$_POST['password'];
	$cpwd=$_POST['c_password'];
	$email=$_SESSION['email'];
	if($pwd==$cpwd)
	{
		$query="update user set password='$pwd' where email='$email'";
		$result=mysqli_query($conn,$query);
		header('location:../login.php?s=2');
	}
	else
	{
		header('location:../forget.php?p=1&error=1');
	}
}
?>