<?php
include('connect.php');

if(isset($_POST['feed_submit']))
{
		$name=$_POST['name'];
		$email=$_POST['email'];
		$subject=$_POST['subject'];
		$msg=$_POST['msg'];
	
		$query = "insert into feedback values('','$name','$email','$subject','$msg')";
		
		$result=mysqli_query($conn,$query);
		
		header('location:../feedback.php?f=1');
}
	?>