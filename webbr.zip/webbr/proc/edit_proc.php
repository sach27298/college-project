<?php
	include('connect.php');
	$u_id=$_SESSION['login_user'];
	if(isset($_REQUEST['theme']))
	{
		$theme=$_REQUEST['theme'];
	}
	if(isset($_POST['name_sub'])) /*givename.php*/
	{
		$sitename=$_POST['sitename'];
		
			if(isset($_REQUEST['theme']))
			{
				$theme=$_REQUEST['theme'];
				$query1 = "insert into edit (u_id,theme_id,sitename) value('$u_id','$theme','$sitename')";
				mysqli_query($conn,$query1);
				header('location:../form.php?theme='.$theme.'');
			}
			else
			{
				$query1 = "insert into edit (u_id,theme_id,sitename) value('$u_id','1','$sitename')";
				mysqli_query($conn,$query1);
				header('location:../after_login.php');
			}
		}
	if(isset($_POST['site_sub']))
	{
			$sitename=$_POST['site_name'];
			$query="update edit set sitename='$sitename' where u_id='$u_id'";
			mysqli_query($conn,$query);
			header('location:../form.php?theme='.$theme.'');
	}
	if(isset($_POST['menu_sub']))
	{
		$nav1=$_POST['nav1'];
		$nav2=$_POST['nav2'];
		$nav3=$_POST['nav3'];
		$nav4=$_POST['nav4'];
		$query = "update edit set nav1='$nav1',nav2='$nav2',nav3='$nav3',nav4='$nav4' where u_id='$u_id'";
		mysqli_query($conn,$query);
		header('location:../form.php?theme='.$theme.'');
	}
	if(isset($_POST['home_sub']))
	{
		$home_heading=$_POST['home_heading'];
		$home_details=$_POST['home_details'];
		$pic = file_get_contents($_FILES["home_bg"]["tmp_name"]);
		$userid = $_SESSION['login_user'];
		$getuname = "select * from user where u_id = '$userid'";
		$getname = mysqli_query($conn,$getuname) or die(mysqli_error($conn));
		while($nrow = mysqli_fetch_object($getname)){
				$dirname = $nrow->email;
				$path = 'c:/xampp/htdocs/project1/usertemp/'.$dirname.'/';
				$path1 = 'c:/xampp/htdocs/project1/usertemp/'.$dirname.'/upload/';
				$path2 = 'usertemp/'.$dirname.'/upload/';
				$path3 = '../upload/';

			if(!file_exists($path1))
			{
				mkdir($path1,0777,true);
			}

		$picdir = "/xampp/htdocs/project1/uploads/";
		$picdir1 = "uploads/";
		$dpimage = $path1.basename($_FILES["home_bg"]["name"]);
		$dpimage1 = $path2.basename($_FILES["home_bg"]["name"]);
		$dpimage2 = $path3.basename($_FILES["home_bg"]["name"]);
		$uploadok = 1;
		$imagefiletype = pathinfo($dpimage,PATHINFO_EXTENSION);

		
		if($imagefiletype != "jpg" && $imagefiletype != "png" && $imagefiletype != "jpeg"){

			echo "Sorry, only JPG, JPEG and PNG file format allowed";
			$uploadok = 1;

		}

		if($uploadok == 0){
          //echo "There is Some problem with your image or form data data, please recheck and try again.";
		}else {

			if(move_uploaded_file($_FILES["home_bg"]["tmp_name"], $path1.$_FILES["home_bg"]["name"])){
                   
				echo "file uploaded successfully";
				$query = "update edit set home_heading='$home_heading',home_details='$home_details', home_bg='$dpimage2' where u_id='$u_id'";
				mysqli_query($conn,$query);
				header('location:../form.php?theme='.$theme.'');
				
			mysqli_query($conn,$query) or die(mysqli_error($conn));

			}else {
				echo "there was an error to register and uploading your image";
			}

		}
			}
		

	}
	if(isset($_POST['about_sub']))
	{
		$about_heading=$_POST['about_heading'];
		$about_details=$_POST['about_details'];
		$pic = file_get_contents($_FILES["about_bg"]["tmp_name"]);
		$pic1 = file_get_contents($_FILES["about_img"]["tmp_name"]);
		$userid = $_SESSION['login_user'];
		$getuname = "select * from user where u_id = '$userid'";
		$getname = mysqli_query($conn,$getuname) or die(mysqli_error($conn));
		while($nrow = mysqli_fetch_object($getname)){
				$dirname = $nrow->email;
				$path = 'c:/xampp/htdocs/project1/usertemp/'.$dirname.'/';
				$path1 = 'c:/xampp/htdocs/project1/usertemp/'.$dirname.'/upload/';
				$path2 = 'usertemp/'.$dirname.'/upload/';
				$path3 = '../upload/';

			if(!file_exists($path1))
			{
				mkdir($path1,0777,true);
			}

		$picdir = "/xampp/htdocs/project1/uploads/";
		$picdir1 = "uploads/";
		$dpimage = $path1.basename($_FILES["about_bg"]["name"]);
		$dpimage1 = $path1.basename($_FILES["about_img"]["name"]);
		$dpimage2 = $path2.basename($_FILES["about_bg"]["name"]);
		$dpimage3 = $path3.basename($_FILES["about_bg"]["name"]);
		$dpimage4 = $path3.basename($_FILES["about_img"]["name"]);
		$uploadok = 1;
		$imagefiletype = pathinfo($dpimage,$dpimage1,PATHINFO_EXTENSION);

		
		if($imagefiletype != "jpg" && $imagefiletype != "png" && $imagefiletype != "jpeg"){

			echo "Sorry, only JPG, JPEG and PNG file format allowed";
			$uploadok = 1;

		}

		if($uploadok == 0){
          //echo "There is Some problem with your image or form data data, please recheck and try again.";
		}else {

			if(move_uploaded_file($_FILES["about_bg"]["tmp_name"], $path1.$_FILES["about_bg"]["name"])){
                if(move_uploaded_file($_FILES["about_img"]["tmp_name"], $path1.$_FILES["about_img"]["name"])){
				echo "file uploaded successfully";
				$query = "update edit set about_heading='$about_heading',about_details='$about_details', about_bg='$dpimage3', about_img='$dpimage4' where u_id='$u_id'";
				mysqli_query($conn,$query);
				header('location:../form.php?theme='.$theme.'');
				
			mysqli_query($conn,$query) or die(mysqli_error($conn));

			}}else {
				echo "there was an error to register and uploading your image";
			}

		}
			}


	}
	if(isset($_POST['feature_sub']))
	{
		$feature_heading=$_POST['feature_heading'];
		$feature_details=$_POST['feature_details'];
		$pic = file_get_contents($_FILES["feature_bg"]["tmp_name"]);
		$pic1 = file_get_contents($_FILES["feature_img"]["tmp_name"]);
		$userid = $_SESSION['login_user'];
		$getuname = "select * from user where u_id = '$userid'";
		$getname = mysqli_query($conn,$getuname) or die(mysqli_error($conn));
		while($nrow = mysqli_fetch_object($getname)){
				$dirname = $nrow->email;
				$path = 'c:/xampp/htdocs/project1/usertemp/'.$dirname.'/';
				$path1 = 'c:/xampp/htdocs/project1/usertemp/'.$dirname.'/upload/';
				$path2 = 'usertemp/'.$dirname.'/upload/';
				$path3 = '../upload/';

			if(!file_exists($path1))
			{
				mkdir($path1,0777,true);
			}

		$picdir = "/xampp/htdocs/project1/uploads/";
		$picdir1 = "uploads/";
		$dpimage = $path1.basename($_FILES["feature_bg"]["name"]);
		$dpimage1 = $path1.basename($_FILES["feature_img"]["name"]);
		$dpimage2 = $path2.basename($_FILES["feature_bg"]["name"]);
		$dpimage3 = $path3.basename($_FILES["feature_bg"]["name"]);
		$dpimage4 = $path3.basename($_FILES["feature_img"]["name"]);
		$uploadok = 1;
		$imagefiletype = pathinfo($dpimage,$dpimage1,PATHINFO_EXTENSION);

		
		if($imagefiletype != "jpg" && $imagefiletype != "png" && $imagefiletype != "jpeg"){

			echo "Sorry, only JPG, JPEG and PNG file format allowed";
			$uploadok = 1;

		}

		if($uploadok == 0){
          //echo "There is Some problem with your image or form data data, please recheck and try again.";
		}else {

			if(move_uploaded_file($_FILES["feature_bg"]["tmp_name"], $path1.$_FILES["feature_bg"]["name"])){
                if(move_uploaded_file($_FILES["feature_img"]["tmp_name"], $path1.$_FILES["feature_img"]["name"])){   
				echo "file uploaded successfully";
				$query = "update edit set feature_heading='$feature_heading',feature_details='$feature_details', feature_bg='$dpimage3', feature_img='$dpimage4' where u_id='$u_id'";
				mysqli_query($conn,$query);
				header('location:../form.php?theme='.$theme.'');
				
			mysqli_query($conn,$query) or die(mysqli_error($conn));

			}}else {
				echo "there was an error to register and uploading your image";
			}

		}
			}

		
	}
	if(isset($_POST['contact_sub']))
	{
		$mobile=$_POST['contact_number'];
		$email=$_POST['contact_email'];
		$address=$_POST['contact_address'];
		$pic = file_get_contents($_FILES["contact_bg"]["tmp_name"]);
		$getuname = "select * from user where u_id = '$u_id'";
		$getname = mysqli_query($conn,$getuname) or die(mysqli_error($conn));
		while($nrow = mysqli_fetch_object($getname)){
				$dirname = $nrow->email;
				$path = 'c:/xampp/htdocs/project1/usertemp/'.$dirname.'/';
				$path1 = 'c:/xampp/htdocs/project1/usertemp/'.$dirname.'/upload/';
				$path2 = 'usertemp/'.$dirname.'/upload/';
				$path3 = '../upload/';

			if(!file_exists($path1))
			{
				mkdir($path1,0777,true);
			}

		$picdir = "/xampp/htdocs/project1/uploads/";
		$picdir1 = "uploads/";
		$dpimage = $path1.basename($_FILES["contact_bg"]["name"]);
		$dpimage1 = $path2.basename($_FILES["contact_bg"]["name"]);
		$dpimage2 = $path3.basename($_FILES["contact_bg"]["name"]);
		$uploadok = 1;
		$imagefiletype = pathinfo($dpimage,PATHINFO_EXTENSION);

		
		if($imagefiletype != "jpg" && $imagefiletype != "png" && $imagefiletype != "jpeg"){

			echo "Sorry, only JPG, JPEG and PNG file format allowed";
			$uploadok = 1;

		}

		if($uploadok == 0){
          //echo "There is Some problem with your image or form data data, please recheck and try again.";
		}else {

			if(move_uploaded_file($_FILES["contact_bg"]["tmp_name"], $path1.$_FILES["contact_bg"]["name"])){
                   
				echo "file uploaded successfully";
				$query = "update edit set contact_number='$mobile',contact_email='$email', contact_address='$address', contact_bg='$dpimage2' where u_id='$u_id'";
				mysqli_query($conn,$query);
				header('location:../form.php?theme='.$theme.'');
				
			mysqli_query($conn,$query) or die(mysqli_error($conn));

			}else {
				echo "there was an error to register and uploading your image";
			}

		}
			}


	}
	if(isset($_POST['feature_sub']))
	{
		$feature_heading=$_POST['feature_heading'];
		$feature_details=$_POST['feature_details'];
		$pic = file_get_contents($_FILES["feature_bg"]["tmp_name"]);
		$userid = $_SESSION['login_user'];
		$getuname = "select * from user where u_id = '$userid'";
		$getname = mysqli_query($conn,$getuname) or die(mysqli_error($conn));
		while($nrow = mysqli_fetch_object($getname)){
				$dirname = $nrow->email;
				$path = 'c:/xampp/htdocs/project1/usertemp/'.$dirname.'/';
				$path1 = 'c:/xampp/htdocs/project1/usertemp/'.$dirname.'/upload/';
				$path2 = 'usertemp/'.$dirname.'/upload/';
				$path3 = '../upload/';

			if(!file_exists($path1))
			{
				mkdir($path1,0777,true);
			}

		$picdir = "/xampp/htdocs/project1/uploads/";
		$picdir1 = "uploads/";
		$dpimage = $path1.basename($_FILES["feature_bg"]["name"]);
		$dpimage1 = $path2.basename($_FILES["feature_bg"]["name"]);
		$dpimage2 = $path3.basename($_FILES["feature_bg"]["name"]);
		$uploadok = 1;
		$imagefiletype = pathinfo($dpimage,PATHINFO_EXTENSION);

		
		if($imagefiletype != "jpg" && $imagefiletype != "png" && $imagefiletype != "jpeg"){

			echo "Sorry, only JPG, JPEG and PNG file format allowed";
			$uploadok = 1;

		}

		if($uploadok == 0){
          //echo "There is Some problem with your image or form data data, please recheck and try again.";
		}else {

			if(move_uploaded_file($_FILES["feature_bg"]["tmp_name"], $path1.$_FILES["feature_bg"]["name"])){
                   
				echo "file uploaded successfully";
				$query = "update edit set feature_bg='$feature_bg',feature_bg='$feature_bg', feature_bg='$dpimage2' where u_id='$u_id'";
				mysqli_query($conn,$query);
				header('location:../form.php?theme='.$theme.'');
				
			mysqli_query($conn,$query) or die(mysqli_error($conn));

			}else {
				echo "there was an error to register and uploading your image";
			}

		}
			}
	}
	if(isset($_POST['social_sub']))
	{
		$fb=$_POST['fb_url'];
		$twitter=$_POST['twitter_url'];
		$gplus=$_POST['gplus_url'];
		$insta=$_POST['insta_url'];
		$query = "update edit set fb_url='$fb',twitter_url='$twitter',gplus_url='$gplus',insta_url='$insta' where u_id='$u_id'";
		mysqli_query($conn,$query);
		header('location:../form.php?theme='.$theme.'');
	}
	if(isset($_REQUEST['t_sub']))
	{
		$t=$_REQUEST['t_sub'];
		$query = "update edit set theme_id='$t' where u_id='$u_id'";
		mysqli_query($conn,$query);
		header('location:../form.php?theme='.$t.'');
	}
?>