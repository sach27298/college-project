<?php
	include('add-ons/header.php');
?>
<div id="contact">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<h2>CHECKOUT</h2>
			</div>
			<form action="#" method="POST" enctype="multipart/form-data">
				<div class="col-md-12 col-sm-12">
					<div class="pp"><label>Name on Card</label></div>
					<div class="col-md-12 col-sm-12">
						<input name="name" type="text" class="form-control" id="name" placeholder="Name" required>
				  	</div>
					<div class="pp"><label>Card Number</label></div>
					<div class="col-md-12 col-sm-12">
						<input type="text" name="dp" class="form-control" id="dp" required>
				  	</div>
					<div class="col-md-12 col-sm-12">
						<div class="col-md-4 col-sm-4 text-left"><label><i class="fa fa-credit-card-alt"></i> CVC</label></div>
						<div class="col-md-8 col-sm-8 text-left"><label>Expiration</label></div>
				  	</div>
					<div class="col-md-4 col-sm-4">
						<input type="text" name="dp" class="form-control" id="dp" placeholder="ex.311" required>
				  	</div>
					<div class="col-md-4 col-sm-4">
						<input type="text" name="dp" class="form-control" id="dp" placeholder="MM" required>
				  	</div>
					<div class="col-md-4 col-sm-4">
						<input type="text" name="dp" class="form-control" id="dp" placeholder="YYYY" required>
				  	</div>
					<div class="col-md-4 col-md-offset-8 col-sm-offset-8 col-sm-4">
						<form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post" target="_blank">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="B3GLFGEV2BSBN">
<input type="image" src="https://www.sandbox.paypal.com/en_US/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.sandbox.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>

					</div>
				</div>
			</form>
		</div>
	</div>
</div>
<?php
	include('add-ons/footer.php');
?>