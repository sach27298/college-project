<?php
include("add-ons/header.php");
?>
<!-- about section -->
<div id="about">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<h2>WEBBR Story</h2>
			</div>
			<div class="col-md-6 col-sm-6">
				<img src="img/about-img.jpg" class="img-responsive" alt="about img">
			</div>
			<div class="col-md-6 col-sm-6">
				<h3>ABOUT US</h3>
				<h4>Designers &amp; Developers</h4>
				<p>WEBBR is webpage builder project that build webpage with your <b>Basic</b> details.WEBBR is design for that people who don't know what is HTML, CSS &amp; PHP codes.</p>
				<p>WEBBR is easy process for create your <b>Own</b> website. WEBBR is very useful for small businesses who don't want to put high amount of money for develop own website.</p>
				<p>you can easily create your template without any <b>Codes</b>.</p>
			</div>
		</div>
	</div>
</div>
<?php
include("add-ons/footer.php");
?>