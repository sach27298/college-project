<?php
include("add-ons/header.php");
?>
<!-- service section -->
<div id="service">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<h2>Workflow</h2>
			</div>
			<div class="col-md-4 col-sm-4">
				<i class="fa fa-desktop"></i>
				<h3>choose themes</h3>
				<p>Choose any themes from given themes.</p>
			</div>
			<div class="col-md-4 col-sm-4">
				<i class="fa fa-edit"></i>
				<h3>Edit</h3>
				<p>Just you need to add your details in your choosen themes for edit template.<a rel="nofollow" href="login.php" target="_parent">start now</a>.</p>
			</div>
			<div class="col-md-4 col-sm-4">
				<i class="fa fa-credit-card-alt"></i>
				<h3>Buy</h3>
				<p>when you done with editing, you can buy your template.</p>
			</div>
		</div>
	</div>
</div>
<?php
include("add-ons/footer.php");
?>