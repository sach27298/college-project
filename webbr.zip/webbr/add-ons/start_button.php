<!-- divider section -->
<div class="container">
	<div class="row">
		<div class="col-md-1 col-sm-1"></div>
		<div class="col-md-10 col-sm-10">
			<hr>
		</div>
		<div class="col-md-1 col-sm-1"></div>
	</div>
</div>
<!-- get started -->
<div id="button">
<div class="container">
	<div class="row">
		<div class="col-md-offset-5 col-md-7 col-sm-offset-5 col-sm-7">
			<a href="register.php" class="btn btn-default smoothScroll">GET STARTED</a>
		</div>
	</div>
</div>
</div>