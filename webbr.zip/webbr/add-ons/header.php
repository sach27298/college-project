<!DOCTYPE HTML>
<html>
<head>
	<title>WEBBR</title>
		<!-- stylesheet css -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/css/font-awesome.css">
	<link rel="stylesheet" href="css/nivo-lightbox.css">
	<link rel="stylesheet" href="css/nivo_themes/default/default.css">
	<link rel="stylesheet" href="css/style.css">
	<!-- google web font css -->
	<link href='http://fonts.googleapis.com/css?family=Raleway:400,300,600,700' rel='stylesheet' type='text/css'>
</head>
<body data-spy="scroll" data-target=".navbar-collapse">

<!-- navigation -->
<div class="navbar navbar-default" role="navigation">
	<div class="container">
		<div class="navbar-header">
			<button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
				<span class="icon icon-bar"></span>
				<span class="icon icon-bar"></span>
				<span class="icon icon-bar"></span>
			</button>
			<a href="index.php" class="navbar-brand smoothScroll">WEBBR</a>
		</div>
		<div class="collapse navbar-collapse">
			<ul class="nav navbar-nav navbar-right active">
				<li><a href="index.php" class="smoothScroll">HOME</a></li>
				<li><a href="services.php" class="smoothScroll">WORKFLOW</a></li>
				<li><a href="about.php" class="smoothScroll">ABOUT</a></li>
				<li><a href="feedback.php" class="smoothScroll">CONTACT</a></li>
				<li><a href="register.php" class="smoothScroll">REGISTER</a></li>
				<li><a href="login.php" class="smoothScroll">LOGIN</a></li>
			</ul>
		</div>
	</div>
</div>