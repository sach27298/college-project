<!-- divider section -->
<div class="container">
	<div class="row">
		<div class="col-md-1 col-sm-1"></div>
		<div class="col-md-10 col-sm-10">
			<hr>
		</div>
		<div class="col-md-1 col-sm-1"></div>
	</div>
</div>

<!-- footer section -->
<footer>
	<div class="container">
		<div class="row">
			<div class="col-md-6 col-sm-6">
				<h2 id="ofc">Our Office</h2>
				<p>Jamnagar, gujarat</p>
				<p>Email: <span>hello@webbr.com</span></p>
				<p>Phone: <span>010-020-0340</span></p>
			</div>
			<div class="col-md-6 col-sm-6">
				<h2>Social Us</h2>
				<ul class="social-icons">
					<li><a href="#" id="fb" class="fa fa-facebook"></a></li>
					<li><a href="#" id="twitter" class="fa fa-twitter"></a></li>
                    <li><a href="#" id="google" class="fa fa-google-plus"></a></li>
					<li><a href="#" id="insta" class="fa fa-instagram"></a></li>
				</ul>
			</div>
		</div>
	</div>
</footer>

<!-- divider section -->
<div class="container">
	<div class="row">
		<div class="col-md-1 col-sm-1"></div>
		<div class="col-md-10 col-sm-10">
			<hr>
		</div>
		<div class="col-md-1 col-sm-1"></div>
	</div>
</div>

<!-- copyright section -->
<div class="copyright">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<p>Copyright &copy; 2017 
                
                - Design: <a rel="nofollow" href="#home" target="_parent">WEBBR</a></p>
			</div>
		</div>
	</div>
	<div class="container">
	<div class="row">
		<div class="col-md-12 col-sm-12 text-center">
			<a href="#"><img src="img/banner.png" class="ad" alt="ad" /></a>
		</div>
	</div>
</div>
</div>

<!-- scrolltop section -->
<a href="#top" class="go-top"><i class="fa fa-angle-up"></i></a>

<!-- javascript js -->	
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>	
<script src="js/nivo-lightbox.min.js"></script>
<script src="js/smoothscroll.js"></script>
<script src="js/jquery.nav.js"></script>
<script src="js/isotope.js"></script>
<script src="js/imagesloaded.min.js"></script>
<script src="js/custom.js"></script>
</body>
</html>