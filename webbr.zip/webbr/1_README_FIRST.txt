see my portfolio:- sachingadhavi.wordpress.com 
this whole website is based for PHP.
this is actually my college project which i make with my classmate.
i took ready HTML,CSS templates and adjust Theming and text and code according to my use.

for checking working site follow the steps
1> put this folder into htdocs folder
2> create local database with name "webbr".
3> import database(with .sql extension) from database folder(webbr.sql file)
4>put theme folder into webbr folder where u find "1_README_FIRST.txt".
5> open index.php using localhost.
6> done.
sachingadhavi.wordpress.com 