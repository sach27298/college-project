-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 27, 2017 at 06:17 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webbr`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(10) NOT NULL,
  `name` varchar(10) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `name`, `email`, `password`) VALUES
(1, 'sachin', 'sachin@webbr.com', 'admin'),
(2, 'karan', 'karan@webbr.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `edit`
--

CREATE TABLE `edit` (
  `u_id` int(10) NOT NULL,
  `theme_id` int(10) NOT NULL,
  `sitename` varchar(20) NOT NULL,
  `nav1` varchar(10) NOT NULL,
  `nav2` varchar(10) NOT NULL,
  `nav3` varchar(10) NOT NULL,
  `nav4` varchar(10) NOT NULL,
  `home_heading` varchar(20) NOT NULL,
  `home_details` varchar(500) NOT NULL,
  `about_heading` varchar(20) NOT NULL,
  `about_details` varchar(500) NOT NULL,
  `feature_heading` varchar(20) NOT NULL,
  `feature_details` varchar(500) NOT NULL,
  `contact_number` varchar(10) NOT NULL,
  `contact_email` varchar(30) NOT NULL,
  `contact_address` varchar(500) NOT NULL,
  `fb_url` varchar(50) NOT NULL,
  `twitter_url` varchar(50) NOT NULL,
  `gplus_url` varchar(50) NOT NULL,
  `insta_url` varchar(50) NOT NULL,
  `home_bg` varchar(2048) NOT NULL,
  `about_bg` varchar(2048) NOT NULL,
  `about_img` varchar(2048) NOT NULL,
  `feature_bg` varchar(2048) NOT NULL,
  `feature_img` varchar(2048) NOT NULL,
  `contact_bg` varchar(2048) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `edit`
--

INSERT INTO `edit` (`u_id`, `theme_id`, `sitename`, `nav1`, `nav2`, `nav3`, `nav4`, `home_heading`, `home_details`, `about_heading`, `about_details`, `feature_heading`, `feature_details`, `contact_number`, `contact_email`, `contact_address`, `fb_url`, `twitter_url`, `gplus_url`, `insta_url`, `home_bg`, `about_bg`, `about_img`, `feature_bg`, `feature_img`, `contact_bg`) VALUES
(2, 1, 'webbr', 'home', 'about us', 'features', 'contact us', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `f_id` int(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `message` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `themes`
--

CREATE TABLE `themes` (
  `theme_id` int(10) NOT NULL,
  `theme_name` varchar(20) NOT NULL,
  `theme_url` varchar(100) NOT NULL,
  `thumbnail_image` varchar(2048) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `themes`
--

INSERT INTO `themes` (`theme_id`, `theme_name`, `theme_url`, `thumbnail_image`) VALUES
(1, 'foodee', 'c:/xampp/htdocs/project1/themes/foodee/', 'thumb_img/theme1.png'),
(18, 'veggi', 'c:/xampp/htdocs/project1/themes/veggi/', 'thumb_img/theme2.png');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `u_id` int(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone_number` varchar(10) NOT NULL,
  `image` varchar(2048) NOT NULL,
  `password` varchar(32) NOT NULL,
  `s_que` varchar(40) NOT NULL,
  `s_ans` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`u_id`, `name`, `email`, `phone_number`, `image`, `password`, `s_que`, `s_ans`) VALUES
(2, 'user01', 'abc@xyz.com', '1234567890', 'uploads/IMG_2829.jpg', '5628ab7a97e4113ee2b0d803d1f65d90', 'What Is Your First Mobile Number?', '1234567890');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `edit`
--
ALTER TABLE `edit`
  ADD PRIMARY KEY (`u_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`f_id`);

--
-- Indexes for table `themes`
--
ALTER TABLE `themes`
  ADD PRIMARY KEY (`theme_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`u_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `f_id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `themes`
--
ALTER TABLE `themes`
  MODIFY `theme_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `u_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
