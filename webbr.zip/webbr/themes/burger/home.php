<?php 
	include('C:\xampp\htdocs\project1\proc\connect.php');
	$u_id=$_SESSION['login_user'];
	$query = "select * from edit where u_id='$u_id'";
	$result=mysqli_query($conn,$query);
	while($row=mysqli_fetch_array($result))
	{
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> <?php echo $row[2];?></title>
<meta name="wthree-textport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Burger Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
	SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="css/style.css" type="text/css" rel="stylesheet" media="all">  
<link href="css/font-awesome.css" rel="stylesheet">   <!-- font-awesome icons -->
<link href="css/lsb.css" rel="stylesheet" type="text/css">  
<link rel="stylesheet" href="css/owl.carousel.css" type="text/css" media="all">
<link rel="stylesheet" href="css/owl.theme.css" type="text/css" media="all">
<!-- //Custom Theme files -->    
<!-- web-fonts -->    
<link href="//fonts.googleapis.com/css?family=Tulpen+One" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Roboto+Condensed:300,300i,400,400i,700,700i" rel="stylesheet">
<!-- //web-fonts -->  
</head>
<body>  
	<!-- banner -->
	<div class="banner jarallax">  
		<div class="banner-agileinfo">  
			<!-- header -->
			<div id="home" class="header">
				<div class="container">
					<div class="header-nav">
						<nav class="navbar navbar-default">
							<!-- Brand and toggle get grouped for better mobile display -->
							<div class="navbar-header">
								<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
									<span class="sr-only">Toggle navigation</span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
								</button>
								<div class="logo">
									<h1><a class="w3lsbrand" href="index.html"><i><?php echo $row[2];?></i></a></h1>
								</div>
							</div> 
							<!-- Collect the nav links, forms, and other content for toggling -->
							<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
							 <ul class="nav navbar-nav">
								<li class="hvr-sweep-to-bottom active"><a href="index.html"><?php echo $row[3];?></a></li>
								<li class="hvr-sweep-to-bottom"><a href="#about" class="scroll"><?php echo $row[4];?></a></li>
								<li class="hvr-sweep-to-bottom"><a href="#services" class="scroll"><?php echo $row[5];?></a></li>
								<li class="hvr-sweep-to-bottom"><a href="#contact" class="scroll"><?php echo $row[6];?></a></li>
							  </ul>
							</div><!-- /.navbar-collapse -->
						</nav>
					</div>
				</div>
			</div>
			<!-- //header -->
			<!-- banner-text -->
			<div class="banner-text" style="background-image:url(<?php echo $row[20]; ?>);">
				<h1><?php echo $row[7];?></h1>
				<p><?php echo $row[8];?></p>
			</div> 
			<!-- //banner-text -->   
		</div>
	</div>
	<!-- //banner -->
	<!-- banner-bottom -->
	<div  id="about" class="banner-bottom" style="background-image:url(<?php echo $row[21]; ?>);">
		<div class="container">
			<div class="col-md-6 banner_bottom_left">
			
				<h3 class="agileits-title"><?php echo $row[9];?></h3>
				<p><?php echo $row[10];?></p>
				<div class="more">
				</div> 
						</div>
			<div class="col-md-6 banner_bottom_right">
				<img  class="img" src="<?php echo $row[22]; ?>">
			</div>
			
		</div>
	</div>
	<!-- banner-bottom -->
	<!-- services -->
	<div id="services" class="services jarallax"  style="background-image:url(<?php echo $row[23]; ?>);">
		<div class="container"> 
			<h3 class="agileits-title w3title1"><?php echo $row[11];?></h3>
			<div class="col-md-6 col-xs-6 w3ls_services_grid">
				<div class="w3ls_services_grid_left">
					<img  class="img" src="<?php echo $row[24]; ?>">
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="col-md-6 col-xs-6 w3ls_services_grid">
				<div class="w3ls_services_grid_left">
				</div>
				<div class="w3ls_services_grid_right">
					<h3><?php echo $row[12];?></h3>
					
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<!-- //services -->
	
	<!-- contact -->
	<div class="contact" id="contact" style="background-image:url(<?php echo $row[25]; ?>);">
		<div class="w3-contact-grids">
			<div class="col-sm-12 w3agile_contact_right"> 
				<h3 class="agileits-title"><a href="index.html">CONTACT</a></h3>
				<div class="w3agile_contact_right_agileinfo">
					<div class="addr">
					<h4>Address</h4>
					<p><span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span><?php echo $row[15];?></p>
					<p><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span> <?php echo $row[13];?></p>
					<p><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span><a href="mailto:<?php echo $row[14];?>"><?php echo $row[14];?></a></p>
				</div>
				</div>
				<div class="w3agile_contact_right_agileinfo">
					<h4 class="addr">Follow Us</h4>
					<div class="social-agile">
						<ul class="addr">
							<li><a href="<?php echo $row[16];?>"><i class="fa fa-facebook"></i></a></li>
							<li><a href="<?php echo $row[17];?>"><i class="fa fa-twitter"></i></a></li>
							<li><a href="<?php echo $row[18];?>"><i class="fa fa-google-plus"></i></a></li>
							<li><a href="<?php echo $row[19];}?>"><i class="fa fa-instagram"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<!-- //contact -->
	<!-- footer -->
	<footer>
		<div class="container">
			<div class="w3_copy_right">
				
			</div>
		</div>
	</footer>
	<!-- //footer --> 
	
	<!-- js --> 
	<script src="js/jquery-2.2.3.min.js"></script>  
	<!-- //js --> 
	<!-- jarallax -->  
	<script src="js/SmoothScroll.min.js"></script> 
	<script src="js/jarallax.js"></script> 
	<script type="text/javascript">
		/* init Jarallax */
		$('.jarallax').jarallax({
			speed: 0.5,
			imgWidth: 1366,
			imgHeight: 768
		})
	</script>  
	<!-- //jarallax --> 
	<!-- start-smooth-scrolling -->
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>	
	<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
			
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
	</script>
	<!-- //end-smooth-scrolling -->	
	<!-- smooth-scrolling-of-move-up -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
			};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
	<!-- //smooth-scrolling-of-move-up -->  
	<!-- gallery-lightbox -->  
	<script src="js/lsb.min.js"></script>
	<script>
	$(window).load(function() {
		  $.fn.lightspeedBox();
		});
	</script> 
	<!-- //gallery-lightbox --> 
	<!-- owl carousel -->   
	<script src="js/owl.carousel.js"></script>
	<script>
	$(document).ready(function() { 
		$("#owl-demo").owlCarousel({
	 
			autoPlay: 3000, //Set AutoPlay to 3 seconds
			autoPlay:true,
			items : 3,
			itemsDesktop : [991,2],
			itemsDesktopSmall : [414,4]
	 
		}); 
	}); 
	</script>
	<!-- //owl carousel -->

	<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/bootstrap.js"></script>
</body>
</html>