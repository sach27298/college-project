<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">
<head>
<title>Burger a Restaurant Category Bootstrap Responsive Template | Home :: w3layouts</title>
<meta name="wthree-textport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Burger Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
	SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="css/style.css" type="text/css" rel="stylesheet" media="all">  
<link href="css/font-awesome.css" rel="stylesheet">   <!-- font-awesome icons -->
<link href="css/lsb.css" rel="stylesheet" type="text/css">  
<link rel="stylesheet" href="css/owl.carousel.css" type="text/css" media="all">
<link rel="stylesheet" href="css/owl.theme.css" type="text/css" media="all">
<!-- //Custom Theme files -->    
<!-- web-fonts -->    
<link href="//fonts.googleapis.com/css?family=Tulpen+One" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Roboto+Condensed:300,300i,400,400i,700,700i" rel="stylesheet">
<!-- //web-fonts -->  
</head>
<body>  
	<!-- banner -->
	<div class="banner jarallax">  
		<div class="banner-agileinfo">  
			<!-- header -->
			<div id="home" class="header">
				<div class="container">
					<div class="header-nav">
						<nav class="navbar navbar-default">
							<!-- Brand and toggle get grouped for better mobile display -->
							<div class="navbar-header">
								<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
									<span class="sr-only">Toggle navigation</span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
								</button>
								<div class="logo">
									<h1><a class="w3lsbrand" href="index.html"><i><span>S</span>ITENAME</i></a></h1>
								</div>
							</div> 
							<!-- Collect the nav links, forms, and other content for toggling -->
							<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
							 <ul class="nav navbar-nav">
								<li class="hvr-sweep-to-bottom active"><a href="index.html">Home</a></li>
								<li class="hvr-sweep-to-bottom"><a href="#about" class="scroll">About</a></li>
								<li class="hvr-sweep-to-bottom"><a href="#services" class="scroll">Fetures</a></li>
								<li class="hvr-sweep-to-bottom"><a href="#contact" class="scroll">Contact Us</a></li>
							  </ul>
							</div><!-- /.navbar-collapse -->
						</nav>
					</div>
				</div>
			</div>
			<!-- //header -->
			<!-- banner-text -->
			<div class="banner-text"> 
				<h2>Home Heading</h2>
				<br>
				<br>
				<br>
				<br>
				<h5>laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure </h5> 
			</div> 
			<!-- //banner-text -->   
		</div>
	</div>
	<!-- //banner -->
	<!-- banner-bottom -->
	<div  id="about" class="banner-bottom" style="background-image:url(images/g4.jpg);">
		<div class="container">
			<div class="col-md-6 banner_bottom_left">
			
				<h3 class="agileits-title"><span>A</span>bout Us</h3>
				<h4>occaecat cupidatat proident</h4>
				<p><i>Ut enim ad minima veniam</i> Quis nostrum exercitationem ullam corporis suscipit 
					laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure 
					reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, 
					vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.</p>
				<div class="more">
				</div> 
						</div>
			<div class="col-md-6 banner_bottom_right">
				<img  class="img" src="images/g1.jpg">
			</div>
			
		</div>
	</div>
	<!-- banner-bottom -->
	<!-- services -->
	<div id="services" class="services jarallax"  style="background-image:url(images/g4.jpg);">
		<div class="container"> 
			<h3 class="agileits-title w3title1"><span>F</span>eatures</h3>
			<div class="col-md-6 col-xs-6 w3ls_services_grid">
				<div class="w3ls_services_grid_left">
					<img  class="img" src="images/g1.jpg">
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="col-md-6 col-xs-6 w3ls_services_grid">
				<div class="w3ls_services_grid_left">
				</div>
				<div class="w3ls_services_grid_right">
					<h3>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit voluptatem sequi nesciunt.</h3>
					
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<!-- //services -->
	
	<!-- contact -->
	<div class="contact" id="contact" style="background-image:url(images/2.jpg);">
		<div class="w3-contact-grids">
			<div class="col-sm-12 w3agile_contact_right"> 
				<h3 class="agileits-title"><a href="index.html">CONTACT</a></h3>
				<div class="w3agile_contact_right_agileinfo">
					<div class="addr">
					<h4>Address</h4>
					<p><span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>8921 California Long Beach <i>PO Box 8921 202 East Ocean.</i></p>
					<p><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>(+) 0983 010 823</p>
					<p><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span><a href="mailto:info@example.com">info@example.com</a></p>
				</div>
				</div>
				<div class="w3agile_contact_right_agileinfo">
					<h4 class="addr">Follow Us</h4>
					<div class="social-agile">
						<ul class="addr">
							<li><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter"></i></a></li>
							<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
							<li><a href="#"><i class="fa fa-instagram"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<!-- //contact -->
	<!-- footer -->
	<footer>
		<div class="container">
			<div class="w3_copy_right">
				
			</div>
		</div>
	</footer>
	<!-- //footer --> 
	
	<!-- js --> 
	<script src="js/jquery-2.2.3.min.js"></script>  
	<!-- //js --> 
	<!-- jarallax -->  
	<script src="js/SmoothScroll.min.js"></script> 
	<script src="js/jarallax.js"></script> 
	<script type="text/javascript">
		/* init Jarallax */
		$('.jarallax').jarallax({
			speed: 0.5,
			imgWidth: 1366,
			imgHeight: 768
		})
	</script>  
	<!-- //jarallax --> 
	<!-- start-smooth-scrolling -->
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>	
	<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
			
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
	</script>
	<!-- //end-smooth-scrolling -->	
	<!-- smooth-scrolling-of-move-up -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
			};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
	<!-- //smooth-scrolling-of-move-up -->  
	<!-- gallery-lightbox -->  
	<script src="js/lsb.min.js"></script>
	<script>
	$(window).load(function() {
		  $.fn.lightspeedBox();
		});
	</script> 
	<!-- //gallery-lightbox --> 
	<!-- owl carousel -->   
	<script src="js/owl.carousel.js"></script>
	<script>
	$(document).ready(function() { 
		$("#owl-demo").owlCarousel({
	 
			autoPlay: 3000, //Set AutoPlay to 3 seconds
			autoPlay:true,
			items : 3,
			itemsDesktop : [991,2],
			itemsDesktopSmall : [414,4]
	 
		}); 
	}); 
	</script>
	<!-- //owl carousel -->

	<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/bootstrap.js"></script>
</body>
</html>